import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        System.out.print("Enter Natural max(int) number for check: ");
//        System.out.printf("Enter Natural [1, %d] number for check: ", Integer.MAX_VALUE);
//        Scanner sc = new Scanner(System.in);
//        int number = sc.nextInt();
//        System.out.println(fibonacci.isFib(number));

//        System.out.println(poltnomSolution.main());

//        System.out.println(integration.main(0, 1, 100));

//        Prism prism = new Prism(1, new Triangle(3, 4, 5));
//        System.out.println("Volume: " + prism.volume());
//        System.out.println("Lateral square: " + prism.lateral_square());

        System.out.println(fibonacci.n_fib(2));

    }

    public static double someFunction(double x) {
        return Math.pow(x, 3.0) - Math.pow(x, 2.5) + x - 33;

    }

}
